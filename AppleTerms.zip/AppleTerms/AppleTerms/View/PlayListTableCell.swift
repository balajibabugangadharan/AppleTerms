//
//  PlayListTableCell.swift
//  AppleTerms
//
//  Created by Balajibabu on 20/08/20.
//  Copyright © 2020 Balajibabu. All rights reserved.
//

import UIKit

class PlayListTableCell: UITableViewCell {

    @IBOutlet weak var playListImageView: UIImageView!
    @IBOutlet weak var artistButton: UIButton!
    @IBOutlet weak var trackLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var genreLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.artistButton.contentHorizontalAlignment = .left
    }
    
    func setPlayListDetail(result: Result) {
        
        let attrs : [NSAttributedString.Key : Any] = [
            NSAttributedString.Key.font : UIFont.systemFont(ofSize: 15.0),
            NSAttributedString.Key.foregroundColor : UIColor.blue,
            NSAttributedString.Key.underlineStyle : NSUnderlineStyle.single.rawValue
        ]
        
        self.playListImageView.setImage(urlstring: result.artworkUrl60 ?? "", placeholderImage: #imageLiteral(resourceName: "ic_PlaceHolder"))
        let buttonTitle = NSAttributedString(string: result.artistName ?? "", attributes: attrs)
        self.artistButton.setAttributedTitle(buttonTitle, for: .normal)
        self.trackLabel.text = result.trackName ?? ""
        self.priceLabel.text = "\(result.trackPrice ?? 0.0)"
        self.genreLabel.text = result.primaryGenreName ?? ""
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
