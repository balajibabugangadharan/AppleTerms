//
//  UIStoryBoard+ReusableView.swift
//  AppleTerms
//
//  Created by Balajibabu on 20/08/20.
//  Copyright © 2020 Balajibabu. All rights reserved.
//

import Foundation
import UIKit

//MARK:- Extensions
protocol ReusableView: class {}

extension ReusableView {
    static var reuseIdentifier: String {
        return String(describing: self)
    }
}

// UIViewController.swift
extension UIViewController: ReusableView { }

// UIStoryboard.swift
extension UIStoryboard {

    static var main : UIStoryboard{
        return UIStoryboard(name: "Main", bundle: nil)
    }
    
    static var account : UIStoryboard{
        return UIStoryboard(name: "Account", bundle: nil)
    }
    
    static var home : UIStoryboard{
        return UIStoryboard(name: "Home", bundle: nil)
    }
    
    func instantiateViewController<T>() -> T where T: ReusableView {
        return instantiateViewController(withIdentifier: T.reuseIdentifier) as! T
    }
    
    func instantiateIDViewController<T>() -> T where T: ReusableView {
        return instantiateViewController(withIdentifier: T.reuseIdentifier + "ID") as! T
    }
    
}
