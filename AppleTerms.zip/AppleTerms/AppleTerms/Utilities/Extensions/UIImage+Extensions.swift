//
//  UIImage+Extensions.swift
//  AppleTerms
//
//  Created by Balajibabu on 20/08/20.
//  Copyright © 2020 Balajibabu. All rights reserved.
//

import UIKit
import AlamofireImage

extension UIImageView{
    
    func setImage(urlstring : String,placeholderImage : UIImage = UIImage()){
        if let url = URL(string: urlstring.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!) {
            self.af.setImage(withURL : url,
                             placeholderImage: placeholderImage,
                             filter : nil,
                             imageTransition: .noTransition)
        }
        else{
            self.image = placeholderImage
        }
    }
}
