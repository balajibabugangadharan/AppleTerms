//
//  Cell+Header+Footer+Extension.swift
//  AppleTerms
//
//  Created by Balajibabu on 20/08/20.
//  Copyright © 2020 Balajibabu. All rights reserved.
//


import Foundation
import UIKit

extension UITableViewCell: ReusableView { }
extension UICollectionViewCell: ReusableView { }
extension UITableViewHeaderFooterView: ReusableView { }

extension UITableView{
    
    func dequeueReusableCell<T>(for index : IndexPath) -> T where T : ReusableView{
        return self.dequeueReusableCell(withIdentifier: T.reuseIdentifier, for: index) as! T
    }
    
    func dequeueReusableHFView<T>() -> T where T: ReusableView {
        return self.dequeueReusableHeaderFooterView(withIdentifier: T.reuseIdentifier) as! T
    }
    
    func registerNib<T : ReusableView>(for type : T.Type){
        self.register(UINib(nibName: type.reuseIdentifier, bundle: nil), forCellReuseIdentifier: type.reuseIdentifier)
    }
    
    func registerHeaderFooter<T : ReusableView>(for type : T.Type){
        self.register(UINib(nibName: type.reuseIdentifier, bundle: nil), forHeaderFooterViewReuseIdentifier: type.reuseIdentifier)
    }
}

extension UICollectionView{
    
    func dequeueReusableCell<T>(for index : IndexPath) -> T where T : ReusableView{
        return self.dequeueReusableCell(withReuseIdentifier: T.reuseIdentifier, for: index) as! T
    }
    
    func registerNib<T : ReusableView>(for type : T.Type){
        self.register(UINib(nibName: type.reuseIdentifier, bundle: nil), forCellWithReuseIdentifier: type.reuseIdentifier)
    }
}

