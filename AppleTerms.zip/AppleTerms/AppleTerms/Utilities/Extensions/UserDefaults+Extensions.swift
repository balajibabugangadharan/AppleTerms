//
//  UserDefaults+Extensions.swift
//  AppleTerms
//
//  Created by Balajibabu on 20/08/20.
//  Copyright © 2020 Balajibabu. All rights reserved.
//

import UIKit

struct Defaults {
    static let kPlayList = "PlayList"
}

extension UserDefaults {
    
    // MARK:- Save Details

    func savePlayList(playList: PlayList?) {

        let encoder = JSONEncoder()
        if let encoded = try? encoder.encode(playList) {
            self.set(encoded, forKey: Defaults.kPlayList)
            self.synchronize()
        }
    }

    // MARK:- Get Details

    func getPlayList() -> PlayList? {

        if let playListData = self.object(forKey: Defaults.kPlayList) as? Data {
            let decoder = JSONDecoder()
            if let playList = try? decoder.decode(PlayList.self, from: playListData) {
                return playList
            }
            return nil
        }
        return nil
    }
}
