//
//  Utilities.swift
//  AppleTerms
//
//  Created by Balajibabu on 20/08/20.
//  Copyright © 2020 Balajibabu. All rights reserved.
//

import UIKit

class Utilities: NSObject {
    
    static let shared = Utilities()
    
    func getDataFromFile<T>(fileName: String, modelName: T.Type) -> T? where T : Decodable  {
            
            if let termsJSON = self.getJSONDataFromFile(fileName: fileName) {
                do {
                    let data = try JSONSerialization.data(withJSONObject: termsJSON, options: .prettyPrinted)
                    let directoryGroup = try JSONDecoder().decode(T.self, from: data)
                    return directoryGroup
                }
                catch {
                    return nil
                }
            }
            return nil
        }
    
    func getJSONDataFromFile(fileName: String) -> Dictionary<String, Any>? {
        let filePath = fileName.replacingOccurrences(of: "file://", with: "")
            if let jsonData = NSData(contentsOfFile: filePath) as Data? {
                do {
                    if let directoryArray = try JSONSerialization.jsonObject(with: jsonData, options: []) as? Dictionary<String, Any> {
                        return directoryArray
                    }
                } catch {
                    print("ERROR: JSON data not retreived")
                    return nil
                }
            }
            return nil
        }

}
