//
//  APIMananger.swift
//  AppleTerms
//
//  Created by Balajibabu on 20/08/20.
//  Copyright © 2020 Balajibabu. All rights reserved.
//

import UIKit
import Alamofire


enum APIError: Error {
    
    case invalidData
    
    public var errorDescription: String? {
        switch self {
        case .invalidData:
            return "Please try again later"
        }
    }
}

enum CustomError: Error {
    case description(message: String)
    var localizedDescription: String { return "Some description here!" }
    
}



enum EncodingValue: String {
    
    case urlEncoding
    case jsonEncoding
    
    func getParameterEncoding() -> ParameterEncoding {
        var encoding:ParameterEncoding = URLEncoding.default
        if self == .jsonEncoding {
            encoding = JSONEncoding.default
        }
        return encoding
    }
}

class APIManager: NSObject {
    
    typealias CompletionCallBack<T:Decodable> = (AFResult<T?>) -> Void
    
    static let shared = APIManager()
    
    func apiDownload<T>(apiName: String, modelName: T.Type, params: [String:Any]?, method: HTTPMethod, encoding:EncodingValue = .urlEncoding, callback: @escaping CompletionCallBack<T>) where T : Decodable {
        
        let destination: DownloadRequest.Destination = { _, _ in
            var documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            documentsURL.appendPathComponent("file.csv")
            return (documentsURL, [.removePreviousFile])
        }
            
            AF.download(
                apiName,
                method: .get,
                parameters: params,
                encoding: encoding.getParameterEncoding(),
                headers: nil,
                to: destination).downloadProgress(closure: { (progress) in
                    //progress closure
                    print(progress)
                }).response(completionHandler: { (defaultDownloadResponse) in
                    
                    guard defaultDownloadResponse.fileURL != nil else {
                        let error = NSError(domain: "", code: 0, userInfo: [
                            NSLocalizedDescriptionKey: "Some problem in downloading the directory. Please try again later."
                        ])
                        callback(.failure(AFError.createURLRequestFailed(error: error)))
                        return
                    }
                    if let url = defaultDownloadResponse.fileURL {
                        let terms = Utilities.shared.getDataFromFile(fileName: url.absoluteString, modelName: T.self)
                        callback(.success(terms))
                    }
                })
        }
    
}
