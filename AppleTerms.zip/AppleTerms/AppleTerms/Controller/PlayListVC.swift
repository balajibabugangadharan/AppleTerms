//
//  PlayListVC.swift
//  AppleTerms
//
//  Created by Balajibabu on 20/08/20.
//  Copyright © 2020 Balajibabu. All rights reserved.
//

import UIKit
import SafariServices

class PlayListVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var playList: PlayList?
    var filteredPlayList: PlayList?
    let config = SFSafariViewController.Configuration()
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.playList = UserDefaults.standard.getPlayList()
        self.config.entersReaderIfAvailable = true
        self.tableView.registerNib(for: PlayListTableCell.self)
        self.tableView.tableFooterView = UIView()

        APIManager.shared.apiDownload(apiName: "http://itunes.apple.com/search?term=all", modelName: PlayList.self, params: nil, method: .get) { (result) in
            switch result {
            case .success(let playListResponse):
                self.playList = playListResponse
                self.filteredPlayList = self.playList
                UserDefaults.standard.savePlayList(playList: self.playList)
                self.tableView.reloadData()
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }

}

// MARK:- UITableView Delegates

extension PlayListVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.filteredPlayList?.results.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: PlayListTableCell = tableView.dequeueReusableCell(withIdentifier: "PlayListTableCell") as! PlayListTableCell
        cell.setPlayListDetail(result: self.filteredPlayList!.results[indexPath.row])
        cell.artistButton.addTarget(self, action: #selector(self.artistSelected(sender:)), for: .touchUpInside)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc = SFSafariViewController(url: URL(string: self.filteredPlayList!.results[indexPath.row].collectionViewURL!)!, configuration: self.config)
        present(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    @objc func artistSelected(sender: UIButton) {
        let buttonPosition:CGPoint = sender.convert(.zero, to:self.tableView)
        let indexPath = self.tableView.indexPathForRow(at: buttonPosition)
        print(indexPath!.row)

        let vc = SFSafariViewController(url: URL(string: self.filteredPlayList!.results[indexPath!.row].artistViewURL!)!, configuration: self.config)
        present(vc, animated: true)
    }
    
    
    
}

// MARK:- SearchBar Delegates

extension PlayListVC: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        guard searchText.count > 0 else {
            self.filteredPlayList = self.playList
            self.tableView.reloadData()
            return
        }
        
        let result = self.playList?.results.filter { (user) -> Bool in
            return user.artistName!.contains(searchText) ||
                user.trackName!.contains(searchText) ||
                "\(user.trackPrice!)".contains(searchText) ||
                user.primaryGenreName!.contains(searchText)
        }
        self.filteredPlayList?.results = result!
        self.tableView.reloadData()
    }
}
