//
//  Terms.swift
//  AppleTerms
//
//  Created by Balajibabu on 20/08/20.
//  Copyright © 2020 Balajibabu. All rights reserved.
//

import Foundation

// MARK: - Terms
struct PlayList: Codable {
    let resultCount: Int
    var results: [Result]
}

// MARK: - Result
struct Result: Codable {
    
    let wrapperType: WrapperType?
    let kind: Kind?
    let artistID, collectionID, trackID: Int?
    let artistName: String?
    let collectionName, trackName, collectionCensoredName, trackCensoredName: String?
    let artistViewURL, collectionViewURL: String?
    let feedURL: String?
    let trackViewURL: String?
    let artworkUrl30: String?
    let artworkUrl60, artworkUrl100: String?
    let collectionPrice: Double?
    let trackPrice, trackRentalPrice, collectionHDPrice, trackHDPrice: Double?
    let trackHDRentalPrice: Double?
    let releaseDate: String?
    let collectionExplicitness: Explicitness?
    let trackExplicitness: Explicitness?
    let trackCount: Int?
    let country: Country?
    let currency: Currency?
    let primaryGenreName: String?
    let contentAdvisoryRating: String?
    let artworkUrl600: String?
    let genreIDS, genres: [String]?
    let copyright: String?
    let previewURL: String?
    let resultDescription: String?
    let discCount, discNumber, trackNumber, trackTimeMillis: Int?
    let shortDescription, longDescription: String?
    let isStreamable: Bool?
    let collectionArtistID: Int?
    let collectionArtistName: String?

    enum CodingKeys: String, CodingKey {
        case wrapperType, kind
        case artistID = "artistId"
        case collectionID = "collectionId"
        case trackID = "trackId"
        case artistName, collectionName, trackName, collectionCensoredName, trackCensoredName
        case artistViewURL = "artistViewUrl"
        case collectionViewURL = "collectionViewUrl"
        case feedURL = "feedUrl"
        case trackViewURL = "trackViewUrl"
        case artworkUrl30, artworkUrl60, artworkUrl100, collectionPrice, trackPrice, trackRentalPrice
        case collectionHDPrice = "collectionHdPrice"
        case trackHDPrice = "trackHdPrice"
        case trackHDRentalPrice = "trackHdRentalPrice"
        case releaseDate, collectionExplicitness, trackExplicitness, trackCount, country, currency, primaryGenreName, contentAdvisoryRating, artworkUrl600
        case genreIDS = "genreIds"
        case genres, copyright
        case previewURL = "previewUrl"
        case resultDescription = "description"
        case discCount, discNumber, trackNumber, trackTimeMillis, shortDescription, longDescription, isStreamable
        case collectionArtistID = "collectionArtistId"
        case collectionArtistName
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.wrapperType = try container.decodeIfPresent(WrapperType.self, forKey: .wrapperType)
        self.kind = try container.decodeIfPresent(Kind.self, forKey: .kind)
        self.artistID = try container.decodeIfPresent(Int.self, forKey: .artistID)
        self.collectionID = try container.decodeIfPresent(Int.self, forKey: .collectionID)
        self.trackID = try container.decodeIfPresent(Int.self, forKey: .trackID)
        self.artistName = try container.decodeIfPresent(String.self, forKey: .artistName)
        self.collectionName = try container.decodeIfPresent(String.self, forKey: .collectionName)
        self.trackName = try container.decodeIfPresent(String.self, forKey: .trackName)
        self.collectionCensoredName = try container.decodeIfPresent(String.self, forKey: .collectionCensoredName)
        self.trackCensoredName = try container.decodeIfPresent(String.self, forKey: .trackCensoredName)
        self.artistViewURL = try container.decodeIfPresent(String.self, forKey: .artistViewURL)
        self.collectionViewURL = try container.decodeIfPresent(String.self, forKey: .collectionViewURL)
        self.feedURL = try container.decodeIfPresent(String.self, forKey: .feedURL)
        self.trackViewURL = try container.decodeIfPresent(String.self, forKey: .trackViewURL)
        self.artworkUrl30 = try container.decodeIfPresent(String.self, forKey: .artworkUrl30)
        self.artworkUrl60 = try container.decodeIfPresent(String.self, forKey: .artworkUrl60)
        self.artworkUrl100 = try container.decodeIfPresent(String.self, forKey: .artworkUrl100)
        self.collectionPrice = try container.decodeIfPresent(Double.self, forKey: .collectionPrice)
        self.trackPrice = try container.decodeIfPresent(Double.self, forKey: .trackPrice)
        self.trackRentalPrice = try container.decodeIfPresent(Double.self, forKey: .trackRentalPrice)
        self.collectionHDPrice = try container.decodeIfPresent(Double.self, forKey: .collectionHDPrice)
        self.trackHDPrice = try container.decodeIfPresent(Double.self, forKey: .trackHDPrice)
        self.trackHDRentalPrice = try container.decodeIfPresent(Double.self, forKey: .trackHDRentalPrice)
        self.releaseDate = try container.decodeIfPresent(String.self, forKey: .releaseDate)
        self.collectionExplicitness = try container.decodeIfPresent(Explicitness.self, forKey: .collectionExplicitness)
        self.trackExplicitness = try container.decodeIfPresent(Explicitness.self, forKey: .trackExplicitness)
        self.trackCount = try container.decodeIfPresent(Int.self, forKey: .trackCount)
        self.country = try container.decodeIfPresent(Country.self, forKey: .country)
        self.currency = try container.decodeIfPresent(Currency.self, forKey: .currency)
        self.primaryGenreName = try container.decodeIfPresent(String.self, forKey: .primaryGenreName)
        self.contentAdvisoryRating = try container.decodeIfPresent(String.self, forKey: .contentAdvisoryRating)
        self.artworkUrl600 = try container.decodeIfPresent(String.self, forKey: .artworkUrl600)
        self.genreIDS = try container.decodeIfPresent([String].self, forKey: .genreIDS)
        self.genres = try container.decodeIfPresent([String].self, forKey: .genres)
        self.copyright = try container.decodeIfPresent(String.self, forKey: .copyright)
        self.previewURL = try container.decodeIfPresent(String.self, forKey: .previewURL)
        self.resultDescription = try container.decodeIfPresent(String.self, forKey: .resultDescription)
        self.discCount = try container.decodeIfPresent(Int.self, forKey: .discCount)
        self.discNumber = try container.decodeIfPresent(Int.self, forKey: .discNumber)
        self.trackNumber = try container.decodeIfPresent(Int.self, forKey: .trackNumber)
        self.trackTimeMillis = try container.decodeIfPresent(Int.self, forKey: .trackTimeMillis)
        self.shortDescription = try container.decodeIfPresent(String.self, forKey: .shortDescription)
        self.longDescription = try container.decodeIfPresent(String.self, forKey: .longDescription)
        self.isStreamable = try container.decodeIfPresent(Bool.self, forKey: .isStreamable)
        self.collectionArtistID = try container.decodeIfPresent(Int.self, forKey: .collectionArtistID)
        self.collectionArtistName = try container.decodeIfPresent(String.self, forKey: .collectionArtistName)
    }
}

enum Explicitness: String, Codable {
    case cleaned = "cleaned"
    case explicit = "explicit"
    case notExplicit = "notExplicit"
}

enum Country: String, Codable {
    case usa = "USA"
}

enum Currency: String, Codable {
    case usd = "USD"
}

enum Kind: String, Codable {
    case featureMovie = "feature-movie"
    case podcast = "podcast"
    case song = "song"
    case tvEpisode = "tv-episode"
}

enum WrapperType: String, Codable {
    case audiobook = "audiobook"
    case track = "track"
}
